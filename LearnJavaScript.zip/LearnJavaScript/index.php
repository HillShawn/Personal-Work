<html>
    <head>
        <script src="js/script.js"></script>
    </head>
    <body>
        <button onclick="revealMessage()">Click me!</button>
        <div id="hiddenMessage" style="display:none">
            <p>You are going on a cruise</p>
        <button id="countDownButton" onclick="countDown()">10</button>
    </body>
</html>

